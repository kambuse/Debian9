module Lolcat
  VERSION = "99.9.69"
end
